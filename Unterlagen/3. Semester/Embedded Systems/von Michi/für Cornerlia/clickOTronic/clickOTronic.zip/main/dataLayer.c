/*
 * dataLayer.c
 *
 *  Created on: 06.10.2022
 *      Author: admin
 */

#include <stdbool.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_random.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "hwFunctions.h"




#define MIN_TIME_TO_CLICK					2000 //ms
#define MAX_TIME_TILL_LOSS					5000
#define TIME_WINDOW							3000

//anfang dunkel, 2-5sec wird led  blau, max zeit 500ms -> erfolgreich, gr�n, sonst rot.
typedef enum{
	notStarted,
	idle,
	started,
	next,
	lost
}gameState_t;

static const char* TAG = "CLKTRONIC_DL";
static gameState_t actualState = notStarted;


//returns a random float between 0 and 1
float getRandom()
{
	return ((float) esp_random() / 0xFFFFFFFF);
}

static volatile int64_t lastClickedAt = 0;
int64_t timeLedBlueOn;
int64_t timeTillLoss;
int64_t maxReactionTime = 500 * 80000;

void setNewTimestamp(int64_t timestamp)
{
	lastClickedAt  = timestamp;
}

int* pAbortPGR = NULL;


static int64_t tempClicked = 0;
//gameLogic needs to be polled!!
void gameLogic()
{

	if(tempClicked != lastClickedAt)
	{
		//*pAbortPGR = 2;
		switch(actualState)
		{
		case notStarted:
			if(lastClickedAt < tempClicked)
			{
				timeLedBlueOn = lastClickedAt + MIN_TIME_TO_CLICK + (double)TIME_WINDOW * getRandom();
				timeTillLoss = timeLedBlueOn + maxReactionTime;
				actualState = started;
			}
			break;
		case idle:

			break;
		case started:
			if(esp_timer_get_time() - timeTillLoss > 0)
			{
				setLedColor(red);
				actualState = lost;
			}
			else if(esp_timer_get_time() - (timeLedBlueOn + lastClickedAt) < maxReactionTime)
			{
				setLedColor(green);
				actualState = next;
			}
			else if(esp_timer_get_time() - timeLedBlueOn > 0)
			{
				setLedColor(blue);
			}
			break;
		case next:
			vTaskDelay(100);
			timeLedBlueOn = esp_timer_get_time() + MIN_TIME_TO_CLICK + (double)TIME_WINDOW * getRandom();
			timeTillLoss = timeLedBlueOn + maxReactionTime;
			actualState = started;
			break;
		case lost:
			setLedColor(red);
			ESP_LOGI(TAG, "You Lost!");
			//vTaskDelay(500);
			//esp_restart();
			break;
		default:
			break;

		}
		tempClicked = lastClickedAt;
		ESP_LOGI(TAG, "new tempClick: %ld", tempClicked);
		ESP_LOGI(TAG, "new lastclick : %ld", lastClickedAt);

	}

	ESP_LOGI(TAG, "state: %d" , actualState);
	ESP_LOGI(TAG, "lastclick #2: %ld", lastClickedAt);

	//ESP_LOGI(TAG, actualState);

}

void configureDataLayer()
{
	registerCallbackButtonEvent(setNewTimestamp);
	ESP_LOGI(TAG, "DL conifg done");
}
