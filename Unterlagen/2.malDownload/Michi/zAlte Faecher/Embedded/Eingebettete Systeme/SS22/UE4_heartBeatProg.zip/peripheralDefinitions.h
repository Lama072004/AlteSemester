/*
 * peripheralDefinitions.h
 *
 *  Created on: 02.05.2022
 *      Author: Michael Geuze
 *
 *
 *      Register addresses and all offsets have been copied from the technical reference manual.
 *      For testing purposes, to some registers and other definitions two underscores have been added because
 *      they were the same as in gpio.h and its dependencies.
 *      The six functions do almost the same as in gpio.h/c but this library is written for ESP32C3 DevKit-M-1.
 *      In case it gets used with other devices there is no guarantee for this to work.
 *		Use reset_pin, then your desired configuration and after read/set/reset functions.
 *		It is not checked if the pins are used with the right configurations on the read/set/reset function!
 */

#ifndef MAIN_PERIPHERALDEFINITIONS_H_
#define MAIN_PERIPHERALDEFINITIONS_H_

#include <stdint.h>

uint8_t gpio_configure_as_output(uint8_t gpioNumber);
uint8_t gpio_configure_as_input(uint8_t gpioNumber);
uint8_t gpio_reset_pin__(uint8_t gpioNumber);
uint8_t gpio_set_output(uint8_t gpioNumber);
uint8_t gpio_reset_output(uint8_t gpioNumber);
uint8_t gpio_read_input(uint8_t gpioNumber);

//Some have the same register names as in driver/gpio.h; added 2 underscores to the name__
#define GPIO_BASE 					0x60004000
#define GPIO_OUT_W1TS_REG__ 		0x0008 // GPIO output set register WT
#define GPIO_OUT_W1TC_REG__ 		0x000C //GPIO output clear register WT
#define GPIO_ENABLE_W1TS_REG__ 		0x0024 // GPIO output enable set register WT
#define GPIO_ENABLE_W1TC_REG__ 		0x0028 //GPIO output enable clear register  WT
#define GPIO_IN_REG__				0x003C //GPIO input register
#define IO_MUX_BASE__				0x60009000 //IO MUX base address
#define IO_MUX_GPIO0_REG__			0x0004

#define GPIO_LOWER_BOUNDARY (0)
#define GPIO_UPPER_BOUNDARY (22)
#define ERROR_GPIO_NUM_INVALID (8)

//Use ONLY with unsigned int. gpioNum<0 is not checked
#define CHECK_PIN_VALID(num) 		if( (num) > GPIO_UPPER_BOUNDARY )\
										{return ERROR_GPIO_NUM_INVALID;}

#define OFFSET_FUN_WPU 8
#define OFFSET_FUN_IE 9
#define OFFSET_MCU_SEL 12


#define GPIO_NUM_0 					0
#define GPIO_NUM_1 					1
#define GPIO_NUM_2 					2
#define GPIO_NUM_3 					3
#define GPIO_NUM_4 					4
#define GPIO_NUM_5 					5
#define GPIO_NUM_6 					6
#define GPIO_NUM_7 					7
#define GPIO_NUM_8 					8
#define GPIO_NUM_9 					9
#define GPIO_NUM_10 				10
#define GPIO_NUM_11 				11
#define GPIO_NUM_12 				12
#define GPIO_NUM_13 				13
#define GPIO_NUM_14 				14
#define GPIO_NUM_15 				15
#define GPIO_NUM_16 				16
#define GPIO_NUM_17 				17
#define GPIO_NUM_18 				18
#define GPIO_NUM_19 				19
#define GPIO_NUM_20 				20

//Bit masks
//Same as in esp_bit_defs.h ; Added 2 underscores to not use the library
#define BIT0__ 0x01
#define BIT1__ 0x02
#define BIT2__ 0x04
#define BIT3__ 0x08
#define BIT4__ 0x10
#define BIT5__ 0x20
#define BIT6__ 0x40
#define BIT7__ 0x80

#define BIT8__ 0x0100
#define BIT9__ 0x0200
#define BIT10__ 0x0400
#define BIT11__ 0x0800
#define BIT12__ 0x1000
#define BIT13__ 0x2000
#define BIT14__ 0x4000
#define BIT15__ 0x8000

//a lot of unused registers. Copied from the technical reference manual. Kept for later use
/*
#define GPIO_BT_SELECT_REG 			0x0000 //GPIO bit select register R/W
#define GPIO_OUT_REG				0x0004 //GPIO output register R/W/SS
#define GPIO_OUT_W1TS_REG 			0x0008 // GPIO output set register WT
#define GPIO_OUT_W1TC_REG 			0x000C //GPIO output clear register WT
#define GPIO_ENABLE_REG 			0x0020 //GPIO output enable register R/W/SS
#define GPIO_ENABLE_W1TS_REG 		0x0024 // GPIO output enable set register WT
#define GPIO_ENABLE_W1TC_REG 		0x0028 //GPIO output enable clear register  WT
#define GPIO_STRAP_REG 				0x0038 //pin strapping register  RO
#define GPIO_IN_REG 				0x003C //GPIO input register  RO
#define GPIO_STATUS_REG 			0x0044 // GPIO interrupt status register R/W/SS
#define GPIO_STATUS_W1TS_REG 		0x0048 // GPIO interrupt status set register WT
#define GPIO_STATUS_W1TC_REG 		0x004C //GPIO interrupt status clear register  WT
#define GPIO_PCPU_INT_REG 			0x005C //GPIO PRO_CPU interrupt status register  RO
#define GPIO_PCPU_NMI_INT_REG 		0x0060 //GPIO PRO_CPU (non-maskable) interrupt status register RO
#define GPIO_STATUS_NEXT_REG 		0x014C //GPIO interrupt source register RO

//GPIO Pin configurations
#define GPIO_PIN0_REG 0x0074 //GPIO pin0 configuration register R/W
#define GPIO_PIN1_REG 0x0078 //GPIO pin1 configuration register R/W
#define GPIO_PIN2_REG 0x007C //GPIO pin2 configuration register R/W
#define GPIO_PIN3_REG 0x0080 //GPIO pin3 configuration register R/W
#define GPIO_PIN4_REG 0x0084 //GPIO pin4 configuration register R/W
#define GPIO_PIN5_REG 0x0088 //GPIO pin5 configuration register R/W
#define GPIO_PIN6_REG 0x008C //GPIO pin6 configuration register R/W
#define GPIO_PIN7_REG 0x0090 //GPIO pin7 configuration register R/W
#define GPIO_PIN8_REG 0x0094 //GPIO pin8 configuration register R/W
#define GPIO_PIN9_REG 0x0098 //GPIO pin9 configuration register R/W
#define GPIO_PIN10_REG 0x009C //GPIO pin10 configuration register R/W
#define GPIO_PIN11_REG 0x00A0 //GPIO pin11 configuration register R/W
#define GPIO_PIN12_REG 0x00A4 //GPIO pin12 configuration register R/W
#define GPIO_PIN13_REG 0x00A8 //GPIO pin13 configuration register R/W
#define GPIO_PIN14_REG 0x00AC //GPIO pin14 configuration register R/W
#define GPIO_PIN15_REG 0x00B0 //GPIO pin15 configuration register R/W
#define GPIO_PIN16_REG 0x00B4 //GPIO pin16 configuration register R/W
#define GPIO_PIN17_REG 0x00B8 //GPIO pin17 configuration register R/W
#define GPIO_PIN18_REG 0x00BC //GPIO pin18 configuration register R/W
#define GPIO_PIN19_REG 0x00C0 //GPIO pin19 configuration register R/W
#define GPIO_PIN20_REG 0x00C4 //GPIO pin20 configuration register R/W
#define GPIO_PIN21_REG 0x00C8 //GPIO pin21 configuration register R/W
*/
//Input function register
/*
 * GPIO_FUNCn_IN_SEL Selection control for peripheral input signal n, selects a pin from the 22 GPIO
 * matrix pins to connect this input signal. Or selects 0x1e for a constantly high input or 0x1f for a
 * constantly low input. (R/W)
 * GPIO_FUNCn_IN_INV_SEL Invert the input value. 1: invert enabled; 0: invert disabled. (R/W)
 * GPIO_SIGn_IN_SEL Bypass GPIO matrix. 1: route signals via GPIO matrix, 0: connect signals directly
 * to peripheral configured in IO MUX. (R/W)
 */

//#define GPIO_FUNC0_IN_SEL_CFG_REG 0x0154 //Configuration register for input signal 0 R/W

//#define GPIO_FUNC1_IN_SEL_CFG_REG 0x0158 //Configuration register for input signal 1 R/W


//Ouptut function register
/*
 * GPIO_FUNCn_OUT_SEL Selection control for GPIO output n. If a value Y (0<=Y<128) is written to
 * this field, the peripheral output signal Y will be connected to GPIO output n. If a value 128 is written
 * to this field, bit n of GPIO_OUT_REG and GPIO_ENABLE_REG will be selected as the output value
 * and output enable. (R/W)
 * GPIO_FUNCn_OUT_INV_SEL 0: Do not invert the output value; 1: Invert the output value. (R/W)
 * GPIO_FUNCn_OEN_SEL 0: Use output enable signal from peripheral; 1: Force the output enable
 * signal to be sourced from bit n of GPIO_ENABLE_REG. (R/W)
 * GPIO_FUNCn_OEN_INV_SEL 0: Do not invert the output enable signal; 1: Invert the output enable
 * signal. (R/W)
 */


#endif /* MAIN_PERIPHERALDEFINITIONS_H_ */
