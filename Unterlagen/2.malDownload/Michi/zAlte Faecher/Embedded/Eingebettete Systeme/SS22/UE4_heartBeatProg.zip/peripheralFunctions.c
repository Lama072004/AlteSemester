/*
 * peripheryFunctions.c
 *
 *  Created on: 04.05.2022
 *      Author: Michael Geuze
 *
 *      Functions for the GPIO and MUX registers. Pointers get dereferenced and bits added/deleted.
 */
#include "peripheralDefinitions.h"
#include <stdint.h>

volatile uint32_t* gpMUXGPIO0Register = (volatile uint32_t*)(IO_MUX_BASE__ | IO_MUX_GPIO0_REG__);
volatile uint32_t* gpGPIOInputRegister = (volatile uint32_t*) (GPIO_BASE | GPIO_IN_REG__);
volatile uint32_t* gpGPIODirOutSetRegister = (volatile uint32_t*)(GPIO_BASE | GPIO_ENABLE_W1TS_REG__);
volatile uint32_t* gpGPIODirOutClearRegister = (volatile uint32_t*)(GPIO_BASE | GPIO_ENABLE_W1TC_REG__);
volatile uint32_t* gpGPIOOutSetRegister = (volatile uint32_t*)(GPIO_BASE | GPIO_OUT_W1TS_REG__);
volatile uint32_t* gpGPIOOutClearRegister = (volatile uint32_t*)(GPIO_BASE | GPIO_OUT_W1TC_REG__);

uint8_t gpio_configure_as_output(uint8_t gpioNumber){
	CHECK_PIN_VALID(gpioNumber)
	(*gpGPIODirOutSetRegister) = (1 << gpioNumber);
	return 0;
}

uint8_t gpio_configure_as_input(uint8_t gpioNumber){
	CHECK_PIN_VALID(gpioNumber)
	(*((gpMUXGPIO0Register) + gpioNumber)) |= (1<< OFFSET_FUN_IE);
	return 0;
}


uint8_t gpio_reset_pin__(uint8_t gpioNumber){
	CHECK_PIN_VALID(gpioNumber)
	(*((gpMUXGPIO0Register) + gpioNumber)) |= (1 << OFFSET_FUN_WPU | 1 << OFFSET_MCU_SEL);
	(*((gpMUXGPIO0Register) + gpioNumber)) &= ~(1<< OFFSET_FUN_IE);
	return 0;
}

uint8_t gpio_set_output(uint8_t gpioNumber){
	CHECK_PIN_VALID(gpioNumber)
	(*gpGPIOOutSetRegister) = (1 << gpioNumber);
	return 0;
}

uint8_t gpio_reset_output(uint8_t gpioNumber){
	CHECK_PIN_VALID(gpioNumber)
	(*gpGPIOOutClearRegister) = (1 << gpioNumber);
	return 0;
}

uint8_t gpio_read_input(uint8_t gpioNumber){
	CHECK_PIN_VALID(gpioNumber)
	return (uint8_t) (BIT0__ & ((*gpGPIOInputRegister) >> gpioNumber));
}








