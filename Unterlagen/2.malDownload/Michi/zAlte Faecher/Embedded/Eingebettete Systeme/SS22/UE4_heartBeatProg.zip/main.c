/*
 * main.c
 *
 *  Created on: 02.05.2022
 *      Author: Michael Geuze
 *
 *		This is kind of a simulated PWM signal generations without using the internal library.
 *		It is neither using the LEDC nor the timer interrupts to generate a reliable on/off sequence.
 *		The idea is just to count every cycle and at a threshold to turn the outputs on and off.
 *		Carrier frequency of the PWM signal is heavily dependent on the expired runtime of the overall code.
 *		Because the CPU is always running, IDLE state of the FREErtos is never reached and the watchdog gets mad.
 *		To prevent every 5 seconds a message popping up on the console and the LEDs to blink, watchdog for IDLE-State
 *		has been disabled in the sdkconfig.
 *
 */

#include "freertos/FreeRTOS.h"
#include "esp_system.h"
#include "esp_event.h"
#include "esp_event_loop.h"
#include "esp_log.h"
//#include "driver/gpio.h"
#include "peripheralDefinitions.h"

#include <stdint.h>

#define LED_OUT_1 GPIO_NUM_6
#define LED_OUT_2 GPIO_NUM_7
#define SENSE_INPUT GPIO_NUM_9

enum pwmState_e{
	incrementVal,
	decrementVal
};

const char* TAG ="HeartBeat.c";

void pwmCycle(uint32_t cycleCount, uint32_t dutyCycle){
	volatile uint32_t cnt = 0;
	uint8_t alreadySetted = 0;			//TODO: workaround for the setting problem. probably is there another
	uint8_t alreadyResetted = 0;		//much nicer way to achieve same goal.
	while(cnt < cycleCount){
		cnt += 1;
		if(!alreadySetted && (cnt < dutyCycle)){
			gpio_set_output(LED_OUT_1);	//TODO: output gets set even if it has already been set.
			gpio_set_output(LED_OUT_2);	//a lot of CPU time probably gets here wasted, same in reset
			alreadySetted = true;
		}
		else if(!alreadyResetted && (cnt >= dutyCycle)){
			gpio_reset_output(LED_OUT_1);
			gpio_reset_output(LED_OUT_2);
			alreadyResetted = true;
		}
	}
}

void configurePeriphery(void){
	gpio_reset_pin__(LED_OUT_1);
	gpio_reset_pin__(LED_OUT_2);
	gpio_reset_pin__(SENSE_INPUT);

	gpio_configure_as_output(LED_OUT_1);
	gpio_configure_as_output(LED_OUT_2);
	gpio_configure_as_input(SENSE_INPUT);
}


void app_main(void)
{
	configurePeriphery();

    uint8_t isPressed = 0;
    uint32_t dutyCycle = 0;
    uint32_t pwmStep = 20;

    //generated frequency, is about 250Hz, changes if runtime differs from initial program
    uint32_t carrierFreqTime = 13000;

    enum pwmState_e state = incrementVal;
    ESP_LOGI(TAG, "Initialized");

    ESP_LOGI(TAG, "New duty Cycle value: %d", pwmStep);

    while (true) {

    	//uses about 4ms of cpu time, no input detection while this
    	//function is running!!
    	pwmCycle(carrierFreqTime, dutyCycle);

    	if(dutyCycle < carrierFreqTime && state == incrementVal){
    		dutyCycle += pwmStep;
    	}else{
    		state = decrementVal;
    	}

    	if(dutyCycle >= pwmStep && state == decrementVal){
    		dutyCycle -= pwmStep;
    	}else{
    		state = incrementVal;
    	}

    	if(!gpio_read_input(SENSE_INPUT) && isPressed == 0){
    		if(pwmStep > 200){
    		    pwmStep = 20;
    		    ESP_LOGI(TAG, "New duty Cycle value: %d", pwmStep);
    		}else{
    			pwmStep += 25;
    			ESP_LOGI(TAG, "New duty Cycle value: %d", pwmStep);
    		}
    		isPressed = 1;
    	}
    	if(gpio_read_input(SENSE_INPUT)){
    		isPressed = 0;
    	}
    }
}

