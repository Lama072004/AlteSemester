/*
 * keydriver.c
 *
 *  Created on: 08.06.2022
 *      Author: Michael Geuze
 *
 *		Read header file.
 *
 */

#include <stdlib.h>
#include "keydriver.h"

static funcNewKeyState_t sNewKeyState = NULL;

void keydriver_main(keydriver_t* kd, bool buttonState){
	bool actStateButton = buttonState;
	if(actStateButton > kd->lastStateButton){
		kd->risingEdgeDetected = true;
	}
	kd->lastStateButton = actStateButton;

	if(kd->risingEdgeDetected && (!kd->keyEvent)){
		kd->keyEvent = true;
	}

	if(kd->keyEvent){
		kd->timeActive += 1;
		if(kd->timeActive > MAX_TIME_DBL_CLICK && actStateButton){
			sNewKeyState(hold);
			kd->holdActive = true;
			kd->timeActive = 0;
		}else if(kd->timeActive > MAX_TIME_DBL_CLICK && !actStateButton){
			sNewKeyState(click);
			kd->keyEvent = false;
		}else if(kd->risingEdgeDetected && kd->timeActive > MIN_TIME_DBL_CLICK){
			sNewKeyState(double_click);
			kd->keyEvent = false;
		}else if(!actStateButton && kd->holdActive){
			sNewKeyState(released);
			kd->holdActive = false;
			kd->keyEvent = false;
		}
	}

	if(!kd->keyEvent){
		kd->timeActive = 0;
	}

	kd->risingEdgeDetected = false;
}

uint8_t getKeyStateHandler(void){
	if(NULL == sNewKeyState){
		return NO_KEY_HANDLER_REGISTERED;
	}else{
		return KEY_HANDLER_REGISTERED;
	}
}

uint8_t registerKeyStateHandler(funcNewKeyState_t ks){
	if(NULL == sNewKeyState){
		sNewKeyState = ks;
		return EXIT_SUCCESS;
	}else{
		return EXIT_FAILURE;
	}
}

uint8_t unregisterKeyStateHandler(void){
	if(NULL == sNewKeyState){
		return EXIT_FAILURE;
	}else{
		sNewKeyState = NULL;
		return EXIT_SUCCESS;
	}
}
