/*
 * main.c
 *
 *  Created on: 08.06.2022
 *      Author: Michael Geuze
 *
 *      Periodically executed main app to get key state. There is a initiation sequence at the beginning. The
 *      used button can be changed.
 */

#include "freertos/FreeRTOS.h"
#include "esp_wifi.h"
#include "esp_system.h"
#include "esp_event.h"
#include "esp_event_loop.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "driver/gpio.h"

#include "keydriver.h"
#include "ledcontrol.h"

#define BUTTON_DIMM_LED 			GPIO_NUM_9

esp_err_t periphery_init();

static const char* TAG = "Dimmer";


extern void dimmerAppInit(void);

void app_main(void)
{
	periphery_init();
	configure_led();
	dimmerAppInit();

	keydriver_t data_keydriver = { 0 };

	ESP_LOGI(TAG, "up and running");

    while (true) {
    	if(getKeyStateHandler()){
    		ESP_LOGI("FAILURE", "No keystate handler registered. Program execution stopped.");
    		vTaskDelay(100);
    		continue;
    	}

    	keydriver_main(&data_keydriver, !gpio_get_level(BUTTON_DIMM_LED));

        vTaskDelay(10 / portTICK_PERIOD_MS);
    }
}


esp_err_t periphery_init(){
	gpio_config_t button = {
			.pin_bit_mask = (1 << BUTTON_DIMM_LED),
			.mode = GPIO_MODE_INPUT,
			.pull_down_en = GPIO_PULLDOWN_DISABLE,
			.pull_up_en = GPIO_PULLUP_ENABLE,
			.intr_type = GPIO_INTR_DISABLE,
	};
	esp_err_t state = ESP_OK;
	state = gpio_config(&button);
	CHECK_ESP_ERROR_STATE(state);

	return  0;
}
