/*
 * dataHandler.c
 *
 *  Created on: 13.06.2022
 *      Author: Michael Geuze
 *
 *
 *      IS NOT WORKING!!!!
 *
 *      PARTITION CANNOT BE FOUND!
 *
 */

#include <stdio.h>
#include <string.h>
#include <sys/unistd.h>
#include <sys/stat.h>
#include "esp_err.h"
#include "esp_log.h"
#include "esp_spiffs.h"

#include "ledcontrol.h"

#define PARTITION_LABEL				"spiffs"
#define DATA_HANDLER_FCT_NAME		"Data Handler"

esp_err_t checkAndCreatePartition();

static FILE* spData = NULL;

FILE* createNewLog(){
	FILE* f = fopen("/spiffs/ledcLog.txt", "w");
	return f;
}

FILE* checkIfLogExists(){
	FILE* f = fopen("/spiffs/ledcLog.txt", "r+");
	return f;
}

bool saveActualData(const ledControl_t* ledOnBoard){
	if(NULL == spData){
		return 1;
	}
	rewind(spData);
	int ret = fprintf(spData, "%d %d %d %d", ledOnBoard->brightness, ledOnBoard->actualColor,
			ledOnBoard->getBrighter, ledOnBoard->stateOn);
	if(ret != 7){
		ESP_LOGI(DATA_HANDLER_FCT_NAME, "Failed to write data!");
		return 1;
	}
	fflush(spData);
	return 0;
}

bool readDataFromSpiffs(ledControl_t* ledOnBoard){
	if(NULL == spData){
		return 0;
	}
	rewind(spData);
	uint32_t brightness;
	bool getBrighter;
	bool stateOn;
	ledColor_t actualColor;
	int ret = fscanf(spData, "%d %d %d %d",&brightness, &actualColor,
			&getBrighter, &stateOn);
	if(ret != 4){
		ESP_LOGI(DATA_HANDLER_FCT_NAME, "Failed to read data!");
		return 1;
	}
	ESP_LOGI(DATA_HANDLER_FCT_NAME, "Data read: %d %d %d %d", brightness, actualColor,
			getBrighter, stateOn);
	ledOnBoard->brightness = brightness;
	ledOnBoard->actualColor = actualColor;
	ledOnBoard->getBrighter = getBrighter;
	ledOnBoard->stateOn = stateOn;

	rewind(spData);
	char* del = "                             ";
	fprintf(spData, "%s", del);

	return 0;
}

void initDataHandler(){
	checkAndCreatePartition();
	spData = checkIfLogExists();
	if(NULL == spData){
		ESP_LOGI(DATA_HANDLER_FCT_NAME, "Creating new logfile");
		spData = createNewLog();
	}else{
		ESP_LOGI(DATA_HANDLER_FCT_NAME, "Logfile opened");
	}
	if(NULL == spData){
		ESP_LOGI(DATA_HANDLER_FCT_NAME, "Failed to create logfile");
	}
}

//checks if partition exists, else, create partition
esp_err_t checkAndCreatePartition(){
	//bool alreadyMounted = esp_spiffs_mounted(PARTITION_LABEL);
	esp_err_t ret = ESP_OK;
    esp_vfs_spiffs_conf_t conf = {
      .base_path = "/spiffs",
      .partition_label = NULL,
      .max_files = 5,
      .format_if_mount_failed = true
    };

    ret = esp_vfs_spiffs_register(&conf);

    if (ret != ESP_OK) {
        if (ret == ESP_FAIL) {
            ESP_LOGE(DATA_HANDLER_FCT_NAME, "Failed to mount or format filesystem");
        } else if (ret == ESP_ERR_NOT_FOUND) {
            ESP_LOGE(DATA_HANDLER_FCT_NAME, "Failed to find SPIFFS partition");
        } else {
            ESP_LOGE(DATA_HANDLER_FCT_NAME, "Failed to initialize SPIFFS (%s)", esp_err_to_name(ret));
        }
        return ret;
    }

    size_t total = 0, used = 0;
    ret = esp_spiffs_info(conf.partition_label, &total, &used);

    ESP_LOGI(DATA_HANDLER_FCT_NAME, "Total: %d, used: %d", total, used);
	return ret;
}



