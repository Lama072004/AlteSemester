/*
 * keydriver.h
 *
 *  Created on: 08.06.2022
 *      Author: Michael Geuze
 *
 *      Can be used to detect wether a key is hold, clicked, double clicked or released. Function which
 *      is registered by the registerKeyStateHandler function gets executed. Must be a funcNewKeyState_t function.
 *      Unregister callback by calling unregisterKeyStateHandler. Actual state gets returned with getKeyStateHandler.
 *
 *      keydriver_main must be executed periodically with the actual keystate. Everything else gets handled by
 *      the driver. Times for changing signals can be set in the definitions.
 *
 */


#ifndef MAIN_KEYDRIVER_H_
#define MAIN_KEYDRIVER_H_

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

typedef struct keydriver_s{
	volatile uint32_t timeActive;
	bool risingEdgeDetected;
	bool lastStateButton;
	bool holdActive;
	bool keyEvent;
}keydriver_t;


typedef enum keyState_e{
	hold,
	click,
	double_click,
	released
}keyState_t;

typedef  void (*funcNewKeyState_t) (keyState_t ks);
uint8_t unregisterKeyStateHandler(void);
uint8_t registerKeyStateHandler(funcNewKeyState_t ks);
uint8_t getKeyStateHandler(void);
void keydriver_main(keydriver_t* kd, bool buttonState);



#define KEY_HANDLER_REGISTERED		0
#define NO_KEY_HANDLER_REGISTERED	1

#define TIME_TILL_HOLD					TIME_TILL_HOLD_MS/MS_DIVISOR
#define MAX_TIME_DBL_CLICK				MAX_TIME_DBL_CLICK_MS/MS_DIVISOR
#define MAX_TIME_SNGL_CLICK				MAX_TIME_SNGL_CLICK_MS/MS_DIVISOR
#define MIN_TIME_DBL_CLICK				MIN_TIME_DBL_CLICK_MS/MS_DIVISOR

#define MS_DIVISOR						10

#define MIN_TIME_DBL_CLICK_MS			120
#define MAX_TIME_SNGL_CLICK_MS			300
#define MAX_TIME_DBL_CLICK_MS			350
#define TIME_TILL_HOLD_MS 				700					//time in ms. only multiples of 10.



#define CHECK_ESP_ERROR_STATE(_s)			if((_s) != ESP_OK){ return _s;}




#endif /* MAIN_KEYDRIVER_H_ */
