/*
 * ledcontrol.c
 *
 *  Created on: 13.06.2022
 *      Author: Michael Geuze
 *
 *      Read header file. Be careful when using static functions.
 *
 */

#include <stddef.h>
#include <stdio.h>
#include "driver/ledc.h"
#include "esp_err.h"

#include "led_strip.h"

#include "ledcontrol.h"


static void setLedColor(const ledControl_t* led);
static inline uint32_t calculateDutyCycle(uint8_t brightness);

static led_strip_t *gpStrip_a;

void switchLedOnOff(ledControl_t* led){
	if(led->stateOn){
		led->stateOn = 0;
	}else{
		led->stateOn = 1;
	}
	writeActualSettingsToLed(led);
}

void ledcInit(void)
{
    // Prepare and then apply the LEDC PWM timer configuration
    ledc_timer_config_t ledc_timer = {
        .speed_mode       = LEDC_MODE,
        .timer_num        = LEDC_TIMER,
        .duty_resolution  = LEDC_DUTY_RES,
        .freq_hz          = LEDC_FREQUENCY,  // Set output frequency at 5 kHz
        .clk_cfg          = LEDC_AUTO_CLK
    };
    ESP_ERROR_CHECK(ledc_timer_config(&ledc_timer));

    // Prepare and then apply the LEDC PWM channel configuration
    ledc_channel_config_t ledc_channel = {
        .speed_mode     = LEDC_MODE,
        .channel        = LEDC_CHANNEL,
        .timer_sel      = LEDC_TIMER,
        .intr_type      = LEDC_INTR_DISABLE,
        .gpio_num       = LEDC_OUTPUT_IO,
        .duty           = 0, // Set duty to 0%
        .hpoint         = 0
    };
    ESP_ERROR_CHECK(ledc_channel_config(&ledc_channel));
}

void changeLedColor(ledControl_t* led){
	if(led->actualColor >= yellow){
		led->actualColor = blue;
	}else{
		led->actualColor +=1;
	}
	writeActualSettingsToLed(led);
}

void configure_led(void)
{
    /* LED strip initialization with the GPIO and pixels number*/
    gpStrip_a = led_strip_init(CONFIG_BLINK_LED_RMT_CHANNEL, FADE_GPIO, 1);
    /* Set all LED off to clear all pixels */
    gpStrip_a->clear(gpStrip_a, 50);

    //Initialise LEDC for pwm signal
    ledcInit();
}

void fadeOneStep(ledControl_t* led){
	if(led->getBrighter){
		if(led->brightness < LED_FADE_STEPS + LED_MINIMUM_BRIGHTNESS){
			led->brightness += 1;
		}
	}
	if(!led->getBrighter){
		if(led->brightness > LED_MINIMUM_BRIGHTNESS){
			led->brightness -=1;
		}
	}
	writeActualSettingsToLed(led);
}

void changeFadeDirection(ledControl_t* led){
	if(led->getBrighter){
		led->getBrighter = false;
	}else{
		led->getBrighter = true;
	}
}

/*
 * 		PRIVATE FUNCTIONS
 *
 */

static inline uint32_t calculateDutyCycle(uint8_t brightness){
	// brightness * (2^LEDC_DUTY_RES -1) / LED_FADE_STEPS, 2^0 = 1, therefore shift -1
	return brightness * (((1 << (LEDC_DUTY_RES-1)) - 1) / LED_FADE_STEPS);
}

static void changeColorToActualBrightness(ledControl_t* led){
	led->red = 0;
	led->blue = 0;
	led->green = 0;
	switch(led->actualColor){
		case blue:
			led->blue = led->brightness * LED_ONBOARD_BRIGHTNESS_MULTIPLIKATOR;
			break;
		case red:
			led->red = led->brightness * LED_ONBOARD_BRIGHTNESS_MULTIPLIKATOR;
			break;
		case green:
			led->green = led->brightness * LED_ONBOARD_BRIGHTNESS_MULTIPLIKATOR;
			break;
		case yellow:
			led->red = led->brightness * LED_ONBOARD_BRIGHTNESS_MULTIPLIKATOR;
			led->green = led->brightness * LED_ONBOARD_BRIGHTNESS_MULTIPLIKATOR;
			break;
	}
}


static void setLedcDutyCycle(const ledControl_t* led){
	if(led->stateOn){
		ledc_set_duty(LEDC_MODE, LEDC_CHANNEL, calculateDutyCycle(led->brightness));
	}else{
		ledc_set_duty(LEDC_MODE, LEDC_CHANNEL, 0);
	}
}

void writeActualSettingsToLed(ledControl_t* led){
	changeColorToActualBrightness(led);
	setLedColor(led);
	setLedcDutyCycle(led);
	ledc_update_duty(LEDC_MODE, LEDC_CHANNEL);
}

static void setLedColor(const ledControl_t* led)
{
	if(NULL != led){
		if(led->stateOn){
			gpStrip_a->set_pixel(gpStrip_a, 0, led->red, led->green, led->blue);
			gpStrip_a->refresh(gpStrip_a, 100);
		}else{
			gpStrip_a->clear(gpStrip_a, 50);
		}
	}
}
