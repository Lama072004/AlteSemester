/*
 * aleaJactaEst.h
 *
 *  Created on: 13.05.2022
 *      Author: Michael Geuze
 */

#ifndef MAIN_ALEAJACTAEST_H_
#define MAIN_ALEAJACTAEST_H_

typedef struct dice_s{
	uint8_t value;
	uint8_t blinkCounter;
	TickType_t blinkSequenceStartSystemCount;
}dice_t;

typedef void (*isrHandler_t) (void*);

void initializeDice(dice_t* dice, uint32_t delayTime);
void shakeDice(dice_t* dice);
void configureDicePeriphery(gpio_num_t input, gpio_num_t led_output, isrHandler_t isrHandler);
bool diceNextBlink(dice_t* dice);
uint32_t getSystemCount();

#define DEBOUNCE_TIME_MS 150
#define BLINK_TICK_RATE_MS 400
#define BLINK_IDLE_TIME_MS 1400

#define ISR_FLAG 0

#endif /* MAIN_ALEAJACTAEST_H_ */
