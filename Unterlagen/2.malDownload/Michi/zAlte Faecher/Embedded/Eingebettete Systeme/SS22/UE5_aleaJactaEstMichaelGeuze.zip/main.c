#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_random.h"
#include "sdkconfig.h"
#include "esp_intr_alloc.h"
#include "aleaJactaEst.h"

#define BUTTON_INPUT GPIO_NUM_9
#define LED_OUT_1 GPIO_NUM_7

static bool gFlagShakeDice = false;
static uint32_t gTimeLast = 0;

void IRAM_ATTR buttonIsrHandler(void* v){
	if((gTimeLast + DEBOUNCE_TIME_MS) < getSystemCount()){
		gFlagShakeDice =  true;
		gTimeLast = getSystemCount();
	}
}

void app_main(void)
{
	configureDicePeriphery(BUTTON_INPUT, LED_OUT_1, buttonIsrHandler);
	dice_t dice;
	while(1){
		if(gFlagShakeDice){
			shakeDice(&dice);
			printf("New random number: %d\n", dice.value);
			gFlagShakeDice = false;
		}

		if (dice.value){
			if(diceNextBlink(&dice)){
				if(dice.blinkCounter %2 == 0){
					gpio_set_level(LED_OUT_1, true);
				}else{
					gpio_set_level(LED_OUT_1, false);
				}
				dice.blinkCounter += 1;
			}
			//reinitiate blink sequence
			if(dice.blinkCounter == (dice.value * 2)){
				initializeDice(&dice, BLINK_IDLE_TIME_MS);
			}
		}
		vTaskDelay(10 / portTICK_PERIOD_MS);
	}
}


