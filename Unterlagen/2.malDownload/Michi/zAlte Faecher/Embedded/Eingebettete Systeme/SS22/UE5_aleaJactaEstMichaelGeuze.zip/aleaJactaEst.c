/*
 * aleaJactaEst.c
 *
 *  Created on: 13.05.2022
 *      Author: Michael Geuze
 *
 */
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_random.h"
#include "aleaJactaEst.h"

#define CHECK_FOR_NULLPTR(ptr) if(NULL==(ptr)){ return; }

uint32_t getSystemCount(){	//returns value in ms
	return xTaskGetTickCount() * portTICK_PERIOD_MS;
}

bool diceNextBlink(dice_t* dice){
	if(NULL == dice){ return 0 ;}
	return ((dice->blinkSequenceStartSystemCount + (BLINK_TICK_RATE_MS * dice->blinkCounter)) < getSystemCount() );
}

void initializeDice(dice_t* dice, uint32_t delayTime){
	CHECK_FOR_NULLPTR(dice);
	dice->blinkSequenceStartSystemCount = getSystemCount() + delayTime;
	dice->blinkCounter = 0;
}

void shakeDice(dice_t* dice){
	CHECK_FOR_NULLPTR(dice);
	dice->value = (esp_random() % 6) + 1;
	initializeDice(dice, 0);
}

void configureDicePeriphery(gpio_num_t input, gpio_num_t led_output, isrHandler_t isrHandler){
	gpio_config_t cfgIn = {
			.pin_bit_mask = (1 << input),
			.mode = GPIO_MODE_INPUT,
			.pull_down_en = GPIO_PULLDOWN_DISABLE,
			.pull_up_en = GPIO_PULLUP_ENABLE,
			.intr_type = GPIO_INTR_NEGEDGE
	};
	gpio_config_t cfgOut = {
			.pin_bit_mask = (1 << led_output),
			.mode = GPIO_MODE_OUTPUT,
			.pull_down_en = GPIO_PULLDOWN_DISABLE,
			.pull_up_en = GPIO_PULLUP_DISABLE,
			.intr_type = GPIO_INTR_DISABLE
	};
	gpio_config(&cfgIn);
	gpio_config(&cfgOut);
	gpio_install_isr_service(ISR_FLAG);
	gpio_isr_handler_add(input, isrHandler, 0);
}
