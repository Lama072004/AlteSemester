//
// 
// To generate a new linked list, create a variable of type list_t and use the functions to add new nodes to the list.
// The function createNode can be used to manually handle the list. It creates a node and returns a pointer to node. 
// If you want to automatically chain your entries together, use insertFront or insertSorted to add a node at 
// front or after a specific value. 
// 
// In the structure list_t you have access to the count of elements and can define an offset to zero. Elements will be counted 
// from there on.
// 
// With deleteList, the whole list gets deleted and the memory is free'd.
// 
// removeFront unchains the first element of the list and returns a pointer to node. Memory must be freed seperately.
// 
// 
// 
// 


#ifndef SINGLY_STRINGED_LIST
#define SINGLY_STRINGED_LIST

#include <stdint.h>

	typedef struct _Node_ {
		uint64_t value;
		struct _Node_* pNext;
	}node_t;

	typedef struct _List_ {
		node_t* pHead;
		uint32_t elements;
	}list_t;


	node_t* createNode(uint64_t value);
	node_t* removeFront(list_t* pList);
	uint32_t retCountOfElements(list_t* pList);
	uint32_t countElements(list_t* pList);
	void printList(list_t* pList);
	void deleteList(list_t* pList);
	void insertFront(list_t* pList, uint64_t value);
	void insertSorted(list_t* pList, uint64_t value);
	void splitList(list_t* pList1, list_t* pList2, uint64_t value);


#endif // !1