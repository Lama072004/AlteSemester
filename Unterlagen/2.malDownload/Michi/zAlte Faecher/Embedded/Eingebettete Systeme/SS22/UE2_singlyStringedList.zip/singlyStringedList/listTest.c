//
// Test program for singly-linked list. 
// All functions first gets tested with an empty list, then with a single node.
// Afterwards every function gets tested with a few entries.
// 
// In case of failure, the program exits with the fault code of the ongoing test. 
//
// 
// 
// Function test for the optional exercise just counts the failed tests and reports at the end of the 
// program if and how many tests have failed.
//




#include <stdio.h>
#include <stdlib.h>

#include "list.h"
#include "optionalUe2.h"

int main() {

	//Arrays with expected values
	uint64_t checkList[] = { 20,25,30,35,40 };
	uint64_t checkListIns1[] = { 20,25,30,32,35,40 };
	uint64_t checkListIns2[] = { 20,25,30,32,32,35,40 };
	uint64_t checkList1Splitted[] = { 20,25,30};
	uint64_t checkList2Splitted[] = { 32,32,35,40 };

	int32_t valTestCounter = -1; //counter for test failed starts at -1, counts down after every test
	
	list_t list1 = { 0 };
	list_t list2 = { 0 };


	//test -1 with empty list
	printf("Testing with empty list\n");
	removeFront(&list1);
	splitList(&list1, &list2, 22);
	deleteList(&list1);
	valTestCounter -= 1;
	printf("Testing with empty list done.\n");

	//test -2
	printf("Inserting 1 element\n");
	insertSorted(&list1, 99);
	if (list1.pHead != NULL && list1.pHead->value != 99 ) {
		exit(valTestCounter);
	}
	valTestCounter -= 1;

	//test -3
	printf("Deleting list\n");
	deleteList(&list1);
	valTestCounter -= 1;

	//test -4
	printf("Testing insertSorted with empty list. Adding 99\n");
	insertSorted(&list1, 99);
	printf("Testing insertSorted with empty list. Adding another element with val 99\n");
	insertSorted(&list1, 99);
	if (list1.pHead != NULL && (list1.pHead->value != 99 || list1.pHead->pNext->value != 99)) {
		exit(valTestCounter);
	}
	valTestCounter -= 1;

	//test -5 InsertFront
	printf("Testing insertFront with value 11\n");
	insertFront(&list1, 11);
	if (list1.pHead == NULL ||list1.pHead->value != 11 || list1.pHead->pNext->value != 99 ||
		list1.pHead->pNext->pNext->value != 99) {
		exit(valTestCounter);
	}
	valTestCounter -= 1;

	//test -6 removeFront
	{
		node_t* removedNode = removeFront(&list1);
		printf("Removed element 11 at front\n");
		if (list1.pHead == NULL || list1.pHead->value != 99 || list1.pHead->pNext->value != 99) {
			exit(valTestCounter);
		}
		valTestCounter -= 1;

		printf("Deleted value: %lld\n", removedNode->value);
		free(removedNode);
		deleteList(&list1);
	}
	
	//Fill list
	printf("Filling list with values from 20-40\n");
	for (uint64_t i = 40; i >= 20; i -= 5) {
		insertFront(&list1, i);
	}
	//test -7 checking values and end of list
	{
		node_t* testNode = list1.pHead;
		int i = 0;
		while (testNode != NULL) {
			if (testNode->value != checkList[i]) {
				exit(valTestCounter);
			}
			i += 1;
			testNode = testNode->pNext;
		}
	}
	valTestCounter -= 1;

	//Test -8 insert sorted with filled list
	printf("Insert sorted value 32\n");
	insertSorted(&list1, 32);
	{	
		node_t *testNode = list1.pHead;
		int i = 0;
		while (testNode != NULL) {
			if (testNode->value != checkListIns1[i]) {
				exit(valTestCounter);
			}
			i += 1;
			testNode = testNode->pNext;
		}
	}
	valTestCounter -= 1;

	//test -9 insertSorted with existing value
	printf("Insert sorted value 32 (2nd time)\n");
	insertSorted(&list1, 32);
	{
		node_t* testNode = list1.pHead;
		int i = 0;
		while (testNode != NULL) {
			if (testNode->value != checkListIns2[i]) {
				exit(valTestCounter);
			}
			i += 1;
			testNode = testNode->pNext;
		}
	}
	valTestCounter -= 1;

	//test -10
	printf("Trying to split list at 100. Value not in list\n");
	splitList(&list1, &list2, 100);
	{
		node_t* testNode = list1.pHead;
		int i = 0;
		while (testNode != NULL) {
			if (testNode->value != checkListIns2[i]) {
				exit(valTestCounter);
			}
			i += 1;
			testNode = testNode->pNext;
		}
	}

	if (list2.pHead != NULL) {
		exit(valTestCounter);
	}
	valTestCounter -= 1;



	//test -11 Splitting list
	printf("Splitting list at 30\n");

	splitList(&list1, &list2, 32);
	{
		node_t* testNode = list1.pHead;
		int i = 0;
		while (testNode != NULL) {
			if (testNode->value != checkList1Splitted[i]) {
				exit(valTestCounter);
			}
			i += 1;
			testNode = testNode->pNext;
		}
	}
	{
		node_t* testNode = list2.pHead;
		int i = 0;
		while (testNode != NULL) {
			if (testNode->value != checkList2Splitted[i]) {
				exit(valTestCounter);
			}
			i += 1;
			testNode = testNode->pNext;
		}
	}
	valTestCounter -= 1;

	printf("List1: \n");
	printList(&list1);
	printf("List2: \n");
	printList(&list2);

	printf("Deleting lists\n");
	deleteList(&list1);
	deleteList(&list2);

	if (valTestCounter == -12) {
		printf("All test successfully finished.\n\n");
	}
	//
	//
	// Test for optional exercise
	//
	//
	{
		printf("Testing optional exercise.\n");
		int optTestCounter = 1;
		int optFailCounter = 0;
		{
			int test = 32;
			int expected = 1;
			if (countBits(test) != expected) {
				printf("Test %d countBits failed!\n", optTestCounter);
				optFailCounter += 1;
			}
			optTestCounter += 1;
		}

		{
			int test = 33;
			int expected = 2;
			if (countBits(test) != expected) {
				printf("Test %d countBits failed!\n", optTestCounter);
				optFailCounter += 1;
			}
			optTestCounter += 1;
		}

		{
			int test = 15;
			int expected = 4;
			if (countBits(test) != expected) {
				printf("Test %d countBits failed!\n", optTestCounter);
				optFailCounter += 1;
			}
			optTestCounter += 1;
		}

		{
			int test = -1;
			int expected = 32;
			if (countBits(test) != expected) {
				printf("Test %d countBits failed!\n", optTestCounter);
				optFailCounter += 1;
			}
			optTestCounter += 1;
		}

		{
			int test = 0;
			int expected = 0;
			if (countBits(test) != expected) {
				printf("Test %d countBits failed!\n", optTestCounter);
				optFailCounter += 1;
			}
			optTestCounter += 1;
		}
		if (optFailCounter == 0) {
			printf("All optional test successufully finished.\n");
		}
		else{
			printf("%d test have failed!\n", optFailCounter);
		}
	}

	return EXIT_SUCCESS;
}