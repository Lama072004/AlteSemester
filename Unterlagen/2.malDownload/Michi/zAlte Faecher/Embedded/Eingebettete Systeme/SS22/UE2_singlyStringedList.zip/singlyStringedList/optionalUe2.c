
int countBits(int value) {
	int retValue = 0;
	if (value > 0) {
		while (value) {
			if (value & 1) {
				retValue += 1;
			}
			value = value >> 1;
		}
	}
	else {
		while (value) {
			if (value & 0x80000000) {
				retValue += 1;
			}
			value = value << 1;
		}
	}
	return retValue;
}