#ifndef OPTIONAL_EX_2
#define OPTIONAL_EX_2

int countBits(int value);

#endif // !OPTIONAL_EX_2
