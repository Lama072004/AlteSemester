#include "list.h"

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

node_t* createNode(uint64_t value) {
	node_t* pNode = malloc(sizeof(node_t));
	if (pNode != NULL) {
		pNode->value = value;
		pNode->pNext = NULL;
	}
	return pNode;
}

void insertFront(list_t* pList, uint64_t value) {
	node_t* pNewNode = createNode(value);
	if (pNewNode == NULL) {
		exit(-1);
	}
	pNewNode->pNext = pList->pHead;
	pList->pHead= pNewNode;
	pList->elements += 1;
}

//removes first node from list and returns pointer to node. Memory has to be freed seperately
node_t* removeFront(list_t* pList) {
	if (pList->pHead == NULL) {
		return NULL;
	}
	node_t* pRemovedNode = pList->pHead;
	pList->pHead = pRemovedNode->pNext;
	pList->elements -= 1;
	return pRemovedNode;
}

void deleteList(list_t* pList) {
	if (pList->pHead == NULL) { //list empty
		return;
	}

	while (pList->pHead != NULL) {	
		node_t* pRemovedNode = removeFront(pList);
		free(pRemovedNode);
		pRemovedNode = NULL;
	}
}

uint32_t retCountOfElements(list_t* pList) {
	return pList->elements;
}

uint32_t countElements(list_t* pList) {
	uint32_t cnt = 0;
	node_t* pActNode = pList->pHead;
	while(pActNode != NULL) {
		cnt += 1;
		pActNode = pActNode->pNext;
	}
	return cnt;
}

void insertSorted(list_t* pList, uint64_t value) {
	if (pList->pHead == NULL) {
		pList->pHead = createNode(value);
		pList->elements += 1;
		return;
	}

	//find node with given value 
	node_t* pActNode = pList->pHead;
	node_t* pPredecessor = pList->pHead; 
	while (pActNode != NULL && value >= pActNode->value) {
			pPredecessor = pActNode;
			pActNode = pActNode->pNext;
	}
	
	//create node at found position, if no entry was found, node will be added to the end of the list
	node_t* newNode = createNode(value);
	newNode->pNext = pActNode;
	pPredecessor->pNext = newNode;
	pList->elements += 1;
}

void splitList(list_t* pList1, list_t* pList2, uint64_t value) {
	if (pList1->pHead == NULL) {
		return;
	}

	//find node with value 
	node_t* pActNode = pList1->pHead;
	node_t* pPredecessor = pList1->pHead;
	while (pActNode != NULL && value > pActNode->value) {
		pPredecessor = pActNode;
		pActNode = pActNode->pNext;
	}
	//Predecessor is the end of list 1
	pPredecessor->pNext = NULL;
	pList1->elements = countElements(pList1);
	
	//Actual node is begin of list 2
	pList2->pHead = pActNode;
	pList2->elements = countElements(pList2);
}

void printList(list_t* pList) {
	printf("List with %u elements:\n", pList->elements);
	node_t* pCurrentNode = pList->pHead;
	while (pCurrentNode != NULL) {
		printf("%lld\n", pCurrentNode->value);
		pCurrentNode = pCurrentNode->pNext;
	}
	printf("\n");
}

