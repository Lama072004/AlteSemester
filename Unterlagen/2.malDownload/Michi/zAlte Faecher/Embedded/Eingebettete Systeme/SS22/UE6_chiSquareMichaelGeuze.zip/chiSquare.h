/*
 * chiSquare.h
 *
 *  Created on: 29.05.2022
 *      Author: Michael Geuze
 *
 *      chiSquare returns the chi square test sum for the given array and parameters. Every element of the array gets casted as double.
 */

#ifndef MAIN_CHISQUARE_H_
#define MAIN_CHISQUARE_H_

#include <stdint.h>

double chiSquare(uint32_t* val, uint32_t len, double expectedFrequency);

#endif /* MAIN_CHISQUARE_H_ */
