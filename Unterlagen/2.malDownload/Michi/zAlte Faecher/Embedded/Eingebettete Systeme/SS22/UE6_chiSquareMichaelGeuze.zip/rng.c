/*
 * rng.c
 *
 *  Created on: 29.05.2022
 *      Author: Michael Geuze
 */


#include "rng.h"

#include <stdint.h>

volatile uint32_t* gpRTC_CNTL_CLK_CONF_REG = (volatile uint32_t*) RTC_CNTL_CLK_CONF_REG_ABS;
volatile uint32_t* gpRNG_DATA = (volatile uint32_t*) RNG_DATA_REG_ABS;

void initializeRNG(){
	(*gpRTC_CNTL_CLK_CONF_REG) |= RTC_CNTL_DIG_FOSC_EN_BITMASK;
}

uint32_t getRandomNumber(){
	uint8_t delay = RNG_DELAY_COUNTER;
	while(delay){
		asm("nop");
		delay -= 1;
	}
	return *gpRNG_DATA;
}
