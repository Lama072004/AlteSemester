/*
 * chiSquare.c
 *
 *  Created on: 29.05.2022
 *      Author: Michael Geuze
 */

#include <stdint.h>
#include <math.h>

static double chiSquarePVT(double val, double exp){
	return (pow((val - exp), 2)) / exp;
}

double chiSquare(uint32_t* val, uint32_t len, double expectedFrequency){
	double sum = 0.0f;
	for(uint32_t i = 0; i < len; i += 1){
		sum += chiSquarePVT(val[i], expectedFrequency);					//implicit conversion to double
	}
	return sum;
}
