/*
 * rng.h
 *
 *  Created on: 29.05.2022
 *      Author: Michael Geuze
 *
 *      Library to use the random number generator. Use the function initializeRNG befor using getRandomNumber. Otherwise the returned values
 *     	pseudo-random numbers.
 *     	To ensure that enough entropy gets into the RNG, every random number needs a bit of time to return.
 *     	You can change the waited time with the parameter RNG_DELAY_COUNTER
 */

#ifndef MAIN_RNG_H_
#define MAIN_RNG_H_

#include <stdint.h>

void initializeRNG();
uint32_t getRandomNumber();

#define APB_CONTROLLER_BASE_ADDRESS				0x60026000
#define RNG_DATA_REG_REL						0x00B0
#define RNG_DATA_REG_ABS						(APB_CONTROLLER_BASE_ADDRESS | RNG_DATA_REG_REL)
#define RNG_DELAY_COUNTER						50								//the higher this value, the more entropy gets into the RNG, max 255

#define LOW_POWER_MANAGEMENT_BASE_ADDRESS		0x60008000
#define RTC_CNTL_CLK_CONF_REG_REL				0x0070
#define RTC_CNTL_CLK_CONF_REG_ABS				(LOW_POWER_MANAGEMENT_BASE_ADDRESS | RTC_CNTL_CLK_CONF_REG_REL )
#define RTC_CNTL_DIG_FOSC_EN_BITMASK 			(1 << 10)

#endif /* MAIN_RNG_H_ */
