/*
 * main.c
 *
 *  Created on: 29.05.2022
 *      Author: Michael Geuze
 */

#include "freertos/FreeRTOS.h"
#include "esp_event.h"
#include "esp_log.h"

#include "rng.h"
#include "chiSquare.h"

const char* TAG = "RNG Test";

#define AMOUNT_OF_SAMPLES 100000
#define AMOUNT_OF_CLASSES 10	//this has to be multiples of 10. Else, information gets lost due to division. If changed, check for new MAXIMUM_CHI_VALUE
#define EXPECTED_FREQUENCY ((double)(AMOUNT_OF_SAMPLES / AMOUNT_OF_CLASSES))

#define MAXIMUM_CHI_VALUE 15.99f				//any value above this means the test was failed, 10% alpha, 10 degrees of freedom

void app_main(void)
{
	initializeRNG();
    while (true) {
    	uint32_t classesTest0[AMOUNT_OF_CLASSES] = { 0 };				//Test with whole range
    	uint32_t classesTest1[AMOUNT_OF_CLASSES] = { 0 };				//Test with range 0-15
    	uint32_t classesTest2[AMOUNT_OF_CLASSES] = { 0 };				//Test with range 0-7

    	for(uint32_t i = 0; i < AMOUNT_OF_SAMPLES; i += 1){
    		classesTest0[getRandomNumber() % AMOUNT_OF_CLASSES ] += 1;
    		classesTest1[(getRandomNumber() % 0xFF) % AMOUNT_OF_CLASSES ] += 1;
    		classesTest2[(getRandomNumber() % 0x0F) % AMOUNT_OF_CLASSES ] += 1;
    	}

    	double chiSumTest0 = chiSquare(classesTest0, AMOUNT_OF_CLASSES, EXPECTED_FREQUENCY);
    	double chiSumTest1 = chiSquare(classesTest1, AMOUNT_OF_CLASSES, EXPECTED_FREQUENCY);
    	double chiSumTest2 = chiSquare(classesTest2, AMOUNT_OF_CLASSES, EXPECTED_FREQUENCY);

    	ESP_LOGI(TAG, "Test with full range: %10.2lf\t\tTest %s", chiSumTest0, chiSumTest0 < MAXIMUM_CHI_VALUE ? "passed" : "failed");
    	ESP_LOGI(TAG, "Test with %% 0xFF:     %10.2lf\t\tTest %s", chiSumTest1, chiSumTest1 < MAXIMUM_CHI_VALUE ? "passed" : "failed");
    	ESP_LOGI(TAG, "Test with %% 0x0F:     %10.2lf\t\tTest %s", chiSumTest2, chiSumTest2 < MAXIMUM_CHI_VALUE ? "passed" : "failed");

        vTaskDelay(1500 / portTICK_PERIOD_MS);
    }
}

