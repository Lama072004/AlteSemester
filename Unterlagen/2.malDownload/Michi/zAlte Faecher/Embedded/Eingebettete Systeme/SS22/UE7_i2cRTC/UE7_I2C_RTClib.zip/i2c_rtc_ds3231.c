/*
 * i2c_rtc_ds3231.c
 *
 *  Created on: 31.05.2022
 *      Author: Michael Geuze
 *
 *      Implementation for the rtc_ds3231 library. Detailed description can be found in the header file.
 *
 */

#include "rtc_ds3231.h"
#include "driver/i2c.h"

esp_err_t i2c_master_ds3231_init(void)
{
    int i2c_master_port = I2C_MASTER_NUM;

    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = I2C_MASTER_SDA_IO,
        .scl_io_num = I2C_MASTER_SCL_IO,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = I2C_MASTER_FREQ_HZ,
    };

    esp_err_t state = i2c_param_config(i2c_master_port, &conf);
    CHECK_ESP_ERROR_STATE(state);

    return i2c_driver_install(i2c_master_port, conf.mode, I2C_MASTER_RX_BUF_DISABLE, I2C_MASTER_TX_BUF_DISABLE, 0);
}


static esp_err_t rtc_ds3231_register_read(uint8_t reg_addr, uint8_t *data, size_t len)
{
    return i2c_master_write_read_device(I2C_MASTER_NUM, RTC_DS3231_I2C_ADDR, &reg_addr, 1, data, len, I2C_MASTER_TIMEOUT_MS / portTICK_PERIOD_MS);
}


static esp_err_t rtc_ds3231__register_write_byte(uint8_t reg_addr, uint8_t data)
{
    uint8_t write_buf[2] = {reg_addr, data};
    return i2c_master_write_to_device(I2C_MASTER_NUM, RTC_DS3231_I2C_ADDR, write_buf, sizeof(write_buf), I2C_MASTER_TIMEOUT_MS / portTICK_PERIOD_MS);
}

static inline uint8_t bcdToDecimal(uint8_t bcd){
	return (bcd & 0x0F) + ((bcd >> 4) * 10);
}

// function not used, conversion is done via macro
//static inline uint8_t decimalToBcd(uint8_t decimal){
//	return (decimal % 10) + ((decimal / 10) << 4) ;
//}

esp_err_t setDateAndTime(time_ds3231_t* data){
	esp_err_t state = ESP_OK;
	uint8_union_t tempBuffer = { .fullByte = 0 };

	state = rtc_ds3231__register_write_byte(RTC_REG_DAY	, data->day);
	CHECK_ESP_ERROR_STATE(state);

	DECIMAL_TO_BCD(tempBuffer, data->date)
	state = rtc_ds3231__register_write_byte(RTC_REG_DATE, tempBuffer.fullByte);
	CHECK_ESP_ERROR_STATE(state);

	tempBuffer.nibble.lowNibble = data->month % 10;
	tempBuffer.fifthBit = data->month / 10;
	state = rtc_ds3231__register_write_byte(RTC_REG_MONTH_CENTURY, tempBuffer.fullByte);
	CHECK_ESP_ERROR_STATE(state);

	DECIMAL_TO_BCD(tempBuffer,data->year)
	state = rtc_ds3231__register_write_byte(RTC_REG_YEAR, tempBuffer.fullByte);
	CHECK_ESP_ERROR_STATE(state);

	DECIMAL_TO_BCD(tempBuffer,data->seconds)
	state = rtc_ds3231__register_write_byte(RTC_REG_SECONDS, tempBuffer.fullByte);
	CHECK_ESP_ERROR_STATE(state);

	DECIMAL_TO_BCD(tempBuffer,data->minutes)
	state = rtc_ds3231__register_write_byte(RTC_REG_MINUTES, tempBuffer.fullByte);
	CHECK_ESP_ERROR_STATE(state);

	DECIMAL_TO_BCD(tempBuffer,data->hours)
	state = rtc_ds3231__register_write_byte(RTC_REG_HOURS, tempBuffer.fullByte);
	CHECK_ESP_ERROR_STATE(state);

	return state;
}

esp_err_t getDateAndTime(time_ds3231_t* data){
	uint8_t tempBuffer = 0;
	esp_err_t state = ESP_OK;

	state = rtc_ds3231_register_read(RTC_REG_SECONDS, &tempBuffer, 1);
	CHECK_ESP_ERROR_STATE(state);
	data->seconds = bcdToDecimal(tempBuffer);

	state = rtc_ds3231_register_read(RTC_REG_MINUTES, &tempBuffer, 1);
	CHECK_ESP_ERROR_STATE(state);
	data->minutes = bcdToDecimal(tempBuffer);

	//TODO: check if 12/24 hour format reader works!!
	state = rtc_ds3231_register_read(RTC_REG_HOURS, &tempBuffer, 1);
	CHECK_ESP_ERROR_STATE(state);
	{
		uint8_t hours = tempBuffer & LOW_BYTE;			//add low byte. No matter what case, its always right
		if(tempBuffer & RTC_TIME_MODE_12H){
			hours += ((tempBuffer & 0x10) >> 4) * 10;	//add lowest bit of higher nibble
			if(tempBuffer & RTC_TIME_IS_PM){
				hours += 12;							//its pm, so +12
			}
		}else{
			hours += ((tempBuffer & 0x30) >> 4) * 10;	//with "normal" time format
		}
		data->hours = hours;
	}

	state = rtc_ds3231_register_read(RTC_REG_DAY, &tempBuffer, 1);
	CHECK_ESP_ERROR_STATE(state);
	data->day = tempBuffer & LOWEST_THREE_BITS;

	state = rtc_ds3231_register_read(RTC_REG_DATE, &tempBuffer, 1);
	CHECK_ESP_ERROR_STATE(state);
	data->date = bcdToDecimal(tempBuffer);

	state = rtc_ds3231_register_read(RTC_REG_MONTH_CENTURY, &tempBuffer, 1);
	CHECK_ESP_ERROR_STATE(state);
	data->month = bcdToDecimal(tempBuffer);

	state = rtc_ds3231_register_read(RTC_REG_YEAR, &tempBuffer, 1);
	CHECK_ESP_ERROR_STATE(state);
	data->year = bcdToDecimal(tempBuffer);

	return state;
}


