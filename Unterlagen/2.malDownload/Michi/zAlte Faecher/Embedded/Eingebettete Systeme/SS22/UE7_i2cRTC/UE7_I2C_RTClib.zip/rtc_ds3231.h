/*
 * rtc_ds3231.h
 *
 *  Created on: 30.05.2022
 *      Author: Michael Geuze
 *
 *      Header file corresponding to the rtc_ds3231 library. You can change the I2C pins and other specifications
 *      in the definitions. Use the time_ds3231_t to set and get date and time. For testing purposes, there are
 *      two different conversion "methods" from bcd to decimal and vice versa. One is made with an static inline
 *      function in the .c file, the other is as macro in the header macro definitions. The macro uses an union
 *      data type to get the right bits.
 *      It has to be checked which is less time and space consuming.
 *
 *      In case one of the functions creates an error, the corresponding esp_err_t will be returned by the function.
 *      If zero (ESP_OK) gets returned, everything works as intended.
 *
 *      Century register gets ignored by now and the library only works for 24h mode.
 *
 *      When setting the time and date, be sure to use legal values for time and date as there is no bound checking.
 *      Date between 1 and 31, time 0 and 59 respective 0 and 23. Date and month should be used with their names in
 *      the enum.
 *      !DO NOT! use a value of 0 for date and month or undefined behavior can occur.
 */

#ifndef MAIN_RTC_DS3231_H_
#define MAIN_RTC_DS3231_H_

#include "esp_err.h"
#include "driver/gpio.h"

typedef struct time_ds3231_s time_ds3231_t;

esp_err_t i2c_master_ds3231_init(void);
esp_err_t setDateAndTime(time_ds3231_t* data);
esp_err_t getDateAndTime(time_ds3231_t* data);

//i2c definitions
//Run in fast mode, pin 4 SCL, pin 5 SDA, 1 sec timeout, addr 0x68
#define I2C_MASTER_SCL_IO          			GPIO_NUM_4     			   /*!< GPIO number used for I2C master clock */
#define I2C_MASTER_SDA_IO          			GPIO_NUM_5				   /*!< GPIO number used for I2C master data  */
#define I2C_MASTER_NUM             			0                          /*!< I2C master i2c port number, the number of i2c peripheral interfaces available will depend on the chip */
#define I2C_MASTER_FREQ_HZ         			400000                     /*!< I2C master clock frequency*/
#define I2C_MASTER_TX_BUF_DISABLE  		 	0                          /*!< I2C master doesn't need buffer */
#define I2C_MASTER_RX_BUF_DISABLE   		0                          /*!< I2C master doesn't need buffer */
#define I2C_MASTER_TIMEOUT_MS       		1000
#define RTC_DS3231_I2C_ADDR                 0x68					   //device address


//Macros
#define CHECK_ESP_ERROR_STATE(_s)			if((_s) != ESP_OK){ return _s;}
#define LOW_NIBBLE_BCD_CODED(buffer,d) {buffer.nibble.lowNibble = (d) % 10;}
#define HIGH_NIBBLE_BCD_CODED(buffer,d) {buffer.nibble.highNibble = (d) / 10;}
#define DECIMAL_TO_BCD(buffer,d) {LOW_NIBBLE_BCD_CODED(buffer,d) HIGH_NIBBLE_BCD_CODED(buffer,d)}

//defines for bit manipulation
#define LOW_BYTE 				0x0F
#define HIGH_BYTE 				0xF0
#define LOWEST_THREE_BITS		0x07

//Datatypes
typedef union {
	struct{
		uint8_t lowNibble :4;
		uint8_t highNibble :4;
	}nibble;
	struct{
		uint8_t lowThreeBits :3;
		uint8_t fourthBit :1;
		uint8_t fifthBit :1;
		uint8_t sixthBit :1;
		uint8_t seventhBit :1;
		uint8_t eigthBit :1;
	};
	uint8_t fullByte;
}uint8_union_t;

typedef enum weekday_e{
	monday = 1,					//Offset for weekday, chip goes on from 1-7
	tuesday,
	wednesday,
	thursday,
	friday,
	saturday,
	sunday
}weekday_t;

typedef enum month_e{
	january = 1,				//Offset for month, chip goes on from 1-12
	february,
	march,
	april,
	may,
	june,
	july,
	august,
	september,
	october,
	november,
	december
}month_t;

typedef struct time_ds3231_s{		//only for 24hr mode
	uint8_t seconds;
	uint8_t minutes;
	uint8_t hours;
	weekday_t day;
	uint8_t date;
	month_t month;
	uint8_t year;
}time_ds3231_t;


//RTC time keeping registers
#define RTC_REG_SECONDS				0x00
#define RTC_REG_MINUTES				0x01
#define RTC_REG_HOURS				0x02
#define RTC_REG_DAY					0x03
#define RTC_REG_DATE				0x04
#define RTC_REG_MONTH_CENTURY		0x05
#define RTC_REG_YEAR				0x06
#define RTC_REG_AL1_SECONDS			0x07
#define RTC_REG_AL1_MINUTES			0x08
#define RTC_REG_AL1_HOURS			0x09
#define RTC_REG_AL1_DAY_DATE		0x0A
#define RTC_REG_AL2_MINUTES			0x0B
#define RTC_REG_AL2_HOURS			0x0C
#define RTC_REG_AL2_DAY_DATE		0x0D
#define RTC_REG_CONTROL				0x0E
#define RTC_REG_CONTROL_STATUS		0x0F
#define RTC_REG_AGING_OFFSET		0x10
#define RTC_REG_MSB_OF_TEMP			0x11
#define RTC_REG_LSB_OF_TEMP			0x12

//Bitmasks for registers
#define RTC_CONTROL_REG_EOSC		BIT7
#define RTC_CONTROL_REG_BBSQW		BIT6
#define RTC_CONTROL_REG_CONV		BIT5
#define RTC_CONTROL_REG_RS2			BIT4
#define RTC_CONTROL_REG_RS1			BIT3
#define RTC_CONTROL_REG_INTCN		BIT2
#define RTC_CONTROL_REG_A2IE		BIT1
#define RTC_CONTROL_REG_A1IE		BIT0

#define RTC_TIME_MODE_12H			BIT6
#define RTC_TIME_IS_PM				BIT5

#define RTC_STATUS_REG_OSF			BIT7
#define RTC_STATUS_REG_EN32kHz		BIT3
#define RTC_STATUS_REG_BSY			BIT2
#define RTC_STATUS_REG_A2F			BIT1
#define RTC_STATUS_REG_A1F			BIT0


#endif /* MAIN_RTC_DS3231_H_ */
