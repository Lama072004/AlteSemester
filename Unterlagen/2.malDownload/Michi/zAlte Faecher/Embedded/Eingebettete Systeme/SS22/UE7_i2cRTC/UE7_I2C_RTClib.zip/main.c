/*
 * main.c
 *
 *  Created on: 31.05.2022
 *      Author: Michael Geuze
 *
 *      Main is the application to test and use the functions of the  rtc_ds3231 library. You can set a new
 *      date and time by pressing the GPIO defined as BUTTON_SET_TIME. The time which is going to be set is
 *      found in main, setTimeTo. You can change date and time. Be sure not to exceed legal values for date
 *      and time as there is no checking implemented for that.
 *
 */

#include "freertos/FreeRTOS.h"
#include "esp_system.h"
#include "esp_event.h"
#include "esp_event_loop.h"
#include "esp_log.h"
#include "driver/gpio.h"
#include "driver/i2c.h"

#include "rtc_ds3231.h"

#define BUTTON_SET_TIME 					GPIO_NUM_9
#define DEBOUNCE_TIME_MS 				   120


static uint8_t gReqToSetTime = 0;
static uint32_t gTimeLast = 0;

uint32_t getSystemCount(){	//returns value in ms
	return xTaskGetTickCount() * portTICK_PERIOD_MS;
}

void isrHandler(void* args){
	if((gTimeLast + DEBOUNCE_TIME_MS) < getSystemCount()){
		gReqToSetTime = 1;
		gTimeLast = getSystemCount();
	}
}

esp_err_t periphery_init(){
	gpio_config_t button = {
			.pin_bit_mask = (1 << BUTTON_SET_TIME),
			.mode = GPIO_MODE_INPUT,
			.pull_down_en = GPIO_PULLDOWN_DISABLE,
			.pull_up_en = GPIO_PULLUP_ENABLE,
			.intr_type = GPIO_INTR_NEGEDGE,
	};
	esp_err_t state = ESP_OK;
	state = gpio_config(&button);
	CHECK_ESP_ERROR_STATE(state);
	state = gpio_install_isr_service(0);
	CHECK_ESP_ERROR_STATE(state);
	state = gpio_isr_handler_add(BUTTON_SET_TIME,isrHandler , 0);
	return  0;
}

void app_main(void)
{
	//plain text of month and day
	//!!! watch out !!! month and weekday have an internal offset. to access the texts, just subtract 1. Else, memory gets corrupted
	const char* weekday [] = { "Monday" , "Tuesday" ,	"Wednesday" , "Thursday" , "Friday" , "Saturday" , "Sunday"};
	const char* month [] =   { "January" , "February" , "March" , "April" , "May" , "June" , "July" ,
									  "August" , "September" , "October" ,"November" , "December" };

	const char* TAG = "I2C_RTC";

	{
		esp_err_t initError = i2c_master_ds3231_init();
		if(initError){
			ESP_LOGI(TAG, "Failed to initialize I2C. Code: %d", initError);
			exit(initError);
		}
		initError = periphery_init();
		if(initError){
			ESP_LOGI(TAG, "Failed to initialize GPIO. Code: %d", initError);
			exit(initError);
		}
	}

	time_ds3231_t actualTime = { 0 };
	time_ds3231_t setTimeTo = {
			.seconds = 12,
			.minutes = 22,
			.hours = 19,
			.day = monday,
			.date = 6,
			.month = june,
			.year = 21
	};

    while (true) {
    	esp_err_t state = getDateAndTime(&actualTime);

    	if(state){
    		ESP_LOGI(TAG, "Failed to get actual values.");
    	}else{
    		ESP_LOGI(TAG, "Time of day: %.2u : %.2u : %.2u" , actualTime.hours, actualTime.minutes, actualTime.seconds);
    		ESP_LOGI(TAG, "%s, %u of %s, 20%.2u" , weekday[actualTime.day - 1],
    				actualTime.date, month[actualTime.month - 1], actualTime.year); //Offset in day and month is because of array starts at 0, chip values start from 1
    	}

    	if(gReqToSetTime){
    		ESP_LOGI(TAG, "Setting new time");
    		setDateAndTime(&setTimeTo);
    		gReqToSetTime = 0;
    	}

        vTaskDelay(1000 / portTICK_PERIOD_MS);
    }
}

