/*
 * dimmerApplication.c
 *
 *  Created on: 08.06.2022
 *      Author: Michael Geuze
 *
 *      Dimmer app for onBoardLed and external led. gets fed by key driver.
 *      dimmerAppInit must be called to register the callback in the key driver.
 *
 *      Functions for data handling do not work yet! Logic for data handling is written at the specific
 *      program lines.
 *
 *      For debugging purposes, at every key event the actual states get echoed out.
 *
 */

#include "esp_log.h"
#include "esp_err.h"
#include "keydriver.h"

static const char* TAG= "App";

#include "ledcontrol.h"

extern esp_err_t checkAndCreatePartition();
extern void createNewLog();
static void dimmerNewKeyState(keyState_t ks);

//data from onboardLed is getting also used to control the LEDC PWM signal!
static ledControl_t ledOnBoard;


void dimmerAppInit(void){
	registerKeyStateHandler(dimmerNewKeyState);

	//check for partition, if none, create new partition. if existing, load data.

//	esp_err_t ret = checkAndCreatePartition();
//	if(ret){
//		createNewLog();
//	}
	//load brightness, color and getBrighter, set state to off
	//loadData(&ledOnBoard);
}

static void dimmerNewKeyState(keyState_t ks){
	switch(ks){
		case released:
			ESP_LOGI(TAG, "released");
			changeFadeDirection(&ledOnBoard);
			break;
		case double_click:
			ESP_LOGI(TAG, "double Click");
			switchLedOnOff(&ledOnBoard);
			break;
		case click:
			ESP_LOGI(TAG, "click");
			if(ledOnBoard.stateOn){
				changeLedColor(&ledOnBoard);
			}
			break;
		case hold:
			ESP_LOGI(TAG, "hold");
			if(ledOnBoard.stateOn){
				fadeOneStep(&ledOnBoard);
			}
			break;
		default:
			break;
	}
	ESP_LOGI(TAG, "brightness: %d, getBrighter: %d, stateOn: %d, actualColor: %d", ledOnBoard.brightness, ledOnBoard.getBrighter, ledOnBoard.stateOn, ledOnBoard.actualColor);

	if(ks != double_click){
		//saveActualData(&ledOnBoard);
		//save brightness, color and getBrighter
	}

}
