/*
 * ledcontrol.h
 *
 *  Created on: 13.06.2022
 *      Author: Michael Geuze
 *
 *
 *      Header to control the onboardLed and to control the LEDC PWM. Use configure_led before using any other function,
 *      else you get NULLptr exception. The GPIO for the LED controlled by the LEDC and the GPIO for the on board
 *      LED can be changed. There are actual 8 fade states, you can configure that as well.
 *
 *      Use the given functions to change the led states.
 */

#ifndef MAIN_LEDCONTROL_H_
#define MAIN_LEDCONTROL_H_

#include <stdint.h>
#include <stdbool.h>



#define FADE_GPIO							8
#define CONFIG_BLINK_LED_RMT_CHANNEL		0
#define LED_FADE_STEPS						8
#define LED_ONBOARD_BRIGHTNESS_MULTIPLIKATOR		16


#define LEDC_TIMER              LEDC_TIMER_0
#define LEDC_MODE               LEDC_LOW_SPEED_MODE
#define LEDC_OUTPUT_IO          (7) // Define the output GPIO
#define LEDC_CHANNEL            LEDC_CHANNEL_0
#define LEDC_DUTY_RES           LEDC_TIMER_13_BIT // Set duty resolution to 13 bits
#define LEDC_DUTY               (4095) // Set duty to 50%. ((2 ** 13) - 1) * 50% = 4095
#define LEDC_FREQUENCY          (5000) // Frequency in Hertz. Set frequency at 5 kHz


typedef enum{
	blue,
	red,
	green,
	yellow
}ledColor_t;

typedef struct ledControl_s{
	uint32_t red;
	uint32_t green;
	uint32_t blue;
	uint32_t brightness;
	bool getBrighter;
	bool stateOn;
	ledColor_t actualColor;
}ledControl_t;

void configure_led(void);
void switchLedOnOff(ledControl_t* led);
void fadeOneStep(ledControl_t* led);
void changeLedColor(ledControl_t* led);
void changeFadeDirection(ledControl_t* led);

#endif /* MAIN_LEDCONTROL_H_ */
