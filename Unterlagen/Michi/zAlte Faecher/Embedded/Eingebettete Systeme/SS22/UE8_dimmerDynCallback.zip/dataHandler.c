/*
 * dataHandler.c
 *
 *  Created on: 13.06.2022
 *      Author: Michael Geuze
 *
 *
 *      IS NOT WORKING!!!!
 *
 *      PARTITION CANNOT BE FOUND!
 *
 */

#include <stdio.h>
#include <string.h>
#include <sys/unistd.h>
#include <sys/stat.h>
#include "esp_err.h"
#include "esp_log.h"
#include "esp_spiffs.h"



#define PARTITION_LABEL				"dimmerPartition"
#define DATA_HANDLER_FCT_NAME		"Data Handler"

//checks if partition exists, else, create partition
esp_err_t checkAndCreatePartition(){
	//esp_err_t ret = esp_spiffs_mounted(PARTITION_LABEL);
	esp_err_t ret = ESP_OK;
    esp_vfs_spiffs_conf_t conf = {
      .base_path = "/spiffs",
      .partition_label = NULL,
      .max_files = 5,
      .format_if_mount_failed = true
    };

    ret = esp_vfs_spiffs_register(&conf);

    if (ret != ESP_OK) {
        if (ret == ESP_FAIL) {
            ESP_LOGE(DATA_HANDLER_FCT_NAME, "Failed to mount or format filesystem");
        } else if (ret == ESP_ERR_NOT_FOUND) {
            ESP_LOGE(DATA_HANDLER_FCT_NAME, "Failed to find SPIFFS partition");
        } else {
            ESP_LOGE(DATA_HANDLER_FCT_NAME, "Failed to initialize SPIFFS (%s)", esp_err_to_name(ret));
        }
        return ret;
    }

    size_t total = 0, used = 0;
    ret = esp_spiffs_info(conf.partition_label, &total, &used);

    ESP_LOGI(DATA_HANDLER_FCT_NAME, "Total: %d, used: %d", total, used);
	return ret;
}

void createNewLog(){
	 ESP_LOGI(DATA_HANDLER_FCT_NAME, "Opening file");
	 FILE* f = fopen("/dimmerPartition/ledcLog.txt", "w");
	 if (f == NULL) {
		 ESP_LOGE(DATA_HANDLER_FCT_NAME, "Failed to open file for writing");
	     return;
	 }
	 fprintf(f, "Hello World!\n");
	 fclose(f);
}


