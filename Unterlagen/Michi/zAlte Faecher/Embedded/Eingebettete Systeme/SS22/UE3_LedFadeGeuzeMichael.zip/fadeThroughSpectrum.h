/*
 * fadeThroughSpectrum.h
 *
 *  Created on: 28.04.2022
 *      Author: Michael Geuze
 */

/*
 * How-To: create a new variable of ledControl_t, initialize with the given function and call
 * the fadeThroughSpectrum. States get automatically changed. Use the values in RGB to let the RGB strip
 * glow. To create other initial states use the given definition and change it. Just keep the order
 * of the transitions in the enum ledFadeState.
 * It is also possible to initialize the LED manually when creating the variable.
 */

#ifndef LED_FADE_THROUGH_SPECTRUM
#define	LED_FADE_THROUGH_SPECTRUM

#define MAX_BRIGHTNESS_LED 16					//Level between 1 and 255

#define INITIAL_LED_STATE_RED
#ifdef INITIAL_LED_STATE_RED
#define INITIAL_LED_VALUE_RED 		MAX_BRIGHTNESS_LED
#define INITIAL_LED_VALUE_GREEN 	0
#define INITIAL_LED_VALUE_BLUE 		0
#define INITIAL_LED_FADE_STATE 		fadeToYellow
#endif

#include <stdint.h>

enum ledFadeState{
	fadeToYellow,
	fadeToGreen,
	fadeToCyan,
	fadeToBlue,
	fadeToViolet,
	fadeToRed,
	restartCycle
};

struct ledControl_s{
	uint32_t red;
	uint32_t green;
	uint32_t blue;
	enum ledFadeState state;
};

typedef struct ledControl_s ledControl_t;

uint8_t initializeLed(ledControl_t* led);
uint8_t fadeThroughSpectrum(ledControl_t* led);

#endif //LED_FADE_THROUGH_SPECTRUM
