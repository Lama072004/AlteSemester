/* Blink Example

   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/
#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "led_strip.h"
#include "sdkconfig.h"

#include "fadeThroughSpectrum.h"

static led_strip_t *gpStrip_a;

#define FADE_GPIO 8
#define RATE_OF_CHANGE_LED 150		//Rate of change * 6 * MAX_BRIGHTNESS_LEVEL(found in fadeThroughSpectrum.h)
									//is the time for a full color changing period in ms
static void setLedColor(const ledControl_t* led)
{
	if(NULL != led){
		gpStrip_a->set_pixel(gpStrip_a, 0, led->red, led->green, led->blue);
		gpStrip_a->refresh(gpStrip_a, 100);
	}
}

static void configure_led(void)
{
    /* LED strip initialization with the GPIO and pixels number*/
    gpStrip_a = led_strip_init(CONFIG_BLINK_LED_RMT_CHANNEL, FADE_GPIO, 1);
    /* Set all LED off to clear all pixels */
    gpStrip_a->clear(gpStrip_a, 50);
}

void app_main(void)
{
	const char *fadeText[] =  {"yellow", "green" , "cyan" , "blue" , "violet" , "red", "cycle restart" }; //TODO: how to get size of the first array? -> prevention of undefined access to element not in fadeText[0-5]
	const char *TAG = "LedFade.c";

    /* Configure the peripheral according to the LED type */
    configure_led();

    ledControl_t ledValues;

    if(initializeLed(&ledValues)){
    	exit(1);
    }
    enum ledFadeState lastState = ledValues.state;
    setLedColor(&ledValues);

    while(1){
    	{
			uint8_t retValue = fadeThroughSpectrum(&ledValues);
			if(retValue){
				//can't happen in normal operation mode unless memory gets corrupted
				ESP_LOGI(TAG, "Failure in function, check conditions! Line:%d File:%s\tCode: %d", __LINE__, __FILE__, retValue);
				continue;
			}
    	}

    	setLedColor(&ledValues);

    	if(lastState != ledValues.state){
    		if(ledValues.state >= fadeToYellow && ledValues.state <= restartCycle){
				ESP_LOGI(TAG, "Fading to %s", fadeText[ledValues.state]);
				lastState = ledValues.state;
    		}else{
    			ESP_LOGI(TAG, "Fade state unknown."); //TODO: mehrfache Abfrage? L64 wird abgebrochen
    		}
    	}

        vTaskDelay(RATE_OF_CHANGE_LED / portTICK_PERIOD_MS);
    }
}
