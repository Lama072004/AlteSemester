/*
 * fadeThroughSpectrum.c
 *
 *  Created on: 28.04.2022
 *      Author: Michael Geuze
 */

#include "fadeThroughSpectrum.h"
#include <stddef.h>
#include <stdint.h>

/* @brief initializes given led with starting values, sets initial color to red, state to fadeToYellow
 *
 * @param led 			ledControl_t to initialize
 * @return 				8 == NULL pointer exception, 0 == OK
 */
uint8_t initializeLed(ledControl_t* led){
	if(NULL == led) return 8;
	led->red = INITIAL_LED_VALUE_RED;
	led->green = INITIAL_LED_VALUE_GREEN;
	led->blue = INITIAL_LED_VALUE_BLUE;
	led->state = INITIAL_LED_FADE_STATE;
	return 0;
}

/* 	@brief changes led values through the standard spectrum
 * 		   maximium brightness can be changed in header file
 *
 *	@param led 			ledControl_t to change
 *	@return 			8 == NULL pointer exception, 1 == reading state failed, reinitialized led values, 0 == OK
 */

uint8_t fadeThroughSpectrum(ledControl_t* led){
	if(NULL == led) return 8;
	uint32_t* colorToChange = NULL;
	switch (led->state){
		case fadeToYellow:
		case fadeToBlue:
			colorToChange = &led->green;
			break;
		case fadeToRed:
		case fadeToCyan:
			colorToChange = &led->blue;
			break;
		case fadeToViolet:
		case fadeToGreen:
			colorToChange = &led->red;
			break;
		default:						//should never be executed. Something's got violated.
			//assert(EXIT_FAILURE);		//ASSERT to prevent this from happening TODO implement assert
			initializeLed(led);			//Reinitializing led values
			return 1;
	}

	//every other state counts up, the others count down
	if((led->state % 2) == 0){
		if(MAX_BRIGHTNESS_LED >= (*colorToChange)){
		 *colorToChange +=1;
		}else{
		 led->state += 1;
		}
	}else{
		if(0 < (*colorToChange)){
		*colorToChange -=1;
		}else{
		led->state += 1;
		}
	}

	 if(restartCycle == led->state){
		 led->state = INITIAL_LED_FADE_STATE;
	 }
	 return 0;
}



