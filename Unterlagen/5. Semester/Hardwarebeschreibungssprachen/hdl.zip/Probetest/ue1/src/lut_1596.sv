//-------------------------------------------
// Projekt  EDB HDL
// Purpose  lut
// Author   Johannes Bilgeri
// Version  v0
//-------------------------------------------

module lut_1596
#(parameter DW = 4)
(
    input   logic  [DW-1:0]  x, // 4bit breiter Eingang
    output  logic            y; // Ausgang
);

always_comb begin
    case(x)
    4'b0100: begin
        y=1'b1;
    end
    4'b1000: begin
        y=1'b1;
    end
    4'1010: begin
        y=1'b1;
    end
    default: begin
        y=1'b0;
    end
    
    endcase
endmodule