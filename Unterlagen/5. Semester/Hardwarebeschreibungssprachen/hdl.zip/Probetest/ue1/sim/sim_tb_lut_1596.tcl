# --- INIT simulation environment ---
vlib work
vmap work work

# --- Compile design files ---
# USE RELATIVE PATHs to the sim folder
vlog ../src/lut_1596.sv

# --- Compile tb files ---
vlog tb_lut_1596.sv

# --- Select the toplevel module ---
vsim lut_1596.sv

# --- Use the correct formating of the wave window ---
#do wave_tb_lut_1596.sv

# --- log all signal recursively ---
log -r *

# --- Run simulation till the end ---
run -all

# --- Show the waveform window ---
view wave
wave zoomful