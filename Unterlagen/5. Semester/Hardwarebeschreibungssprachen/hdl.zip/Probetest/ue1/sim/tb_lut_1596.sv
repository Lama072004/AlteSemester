//-------------------------------------------
// Projekt  EDB HDL
// Purpose  lut
// Author   Johannes Bilgeri
// Version  v0
//-------------------------------------------
/ TestBench (TB) has no Input and Outputs

module tb_lut_1596 ();

// (1) Wires to Device Under Test (DUT)     / Leiterplatte bereitstellen
// copy IOs
    logic   [3:0]       x;
    logic               y;

 // (2) DUT instance
 dreg dut (.*);

// (3) Stimulate the input                  
    initial begin
        for (int i = 0; i < 16; i++)
            begin
                x = i;
                #100ns;
                $display("Input: %d", x);
                $display("Output: %d", y);
                if ((x == 4) || (x = 8) || (x = 10))begin
                    if (y = 1)begin
                        //Alles OK
                    end
                    else begin
                        error_cnt++;
                    end
                end
                else begin
                    if (y == 0)begin
                        //Alles OK
                    end
                    else begin
                        error_cnt++;
                    end
                end

            end


        if (error_cnt == 0) begin           // error count ausgabe
            $display("------------------------------------------------------");
            $display("------------------------------------------------------");
            $display("FINAL MESSAGE:");
            $display("PASS! tb_dreg found %d errors", error_cnt);
        end
        else begin
            $display("------------------------------------------------------");
            $display("------------------------------------------------------");
            $display("FINAL MESSAGE:");
            $display("FAIL! tb_dreg found %d errors", error_cnt);
        end
        #100ns;

endmodule


