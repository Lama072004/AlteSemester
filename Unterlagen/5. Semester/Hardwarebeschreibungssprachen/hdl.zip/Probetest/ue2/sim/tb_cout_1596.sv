//-------------------------------------------
// Projekt  EDB HDL
// Purpose  lut
// Author   Johannes Bilgeri
// Version  v0
//-------------------------------------------